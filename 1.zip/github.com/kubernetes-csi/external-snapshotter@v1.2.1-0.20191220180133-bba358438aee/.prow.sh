#! /bin/bash

CSI_PROW_TESTS="unit"

. release-tools/prow.sh

main
